#include "gtest/gtest.h"

int main(){
    testing::InitGoogleTest();
    return RUN_ALL_TESTS();
}
