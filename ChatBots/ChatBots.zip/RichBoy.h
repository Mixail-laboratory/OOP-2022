#ifndef CHATBOTS_RICHBOY_H
#define CHATBOTS_RICHBOY_H
#include "User.h"

struct RichBoy {

    struct User base_user;

};


extern const void *RichBoy;
#endif
