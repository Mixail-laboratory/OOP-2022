#ifndef CHATBOTS_BOY_H
#define CHATBOTS_BOY_H
#include "User.h"

struct Boy {

    struct User base_user;

};


extern const void *Boy;
#endif
