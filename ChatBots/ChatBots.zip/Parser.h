#ifndef CHATBOTS_PARSER_H
#define CHATBOTS_PARSER_H

void* parse_file(const char* file);
void* parse_line(const char* line);
#endif
