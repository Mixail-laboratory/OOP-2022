#ifndef CHATBOTS_GIRL_H
#define CHATBOTS_GIRL_H
#include "User.h"
struct Girl {

    struct User base_user;

};


extern const void *Girl;
#endif //CHATBOTS_GIRL_H
