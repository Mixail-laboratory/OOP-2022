#ifndef CHATBOTS_COWARDGIRL_H
#define CHATBOTS_COWARDGIRL_H

#include "Girl.h"

struct CowardGirl {
    struct Girl base_girl;
};

extern const void *CowardGirl;
#endif
